Lua scripts are similar to the files that are currently run via the //exec windower command.  Instead of just executing commands, though, Lua scripts are capable of their own logic and decision making.

Once a Lua script finishes running, it is unloaded.

You can run lua scripts via the //lua exec command.  For example, if you have a Lua script named test.lua, you would run it by typing:
//lua exec test
or
//lua e test
