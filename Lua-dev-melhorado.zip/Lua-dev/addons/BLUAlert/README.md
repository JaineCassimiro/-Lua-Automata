Are you sick and tired of watching your chat log like a hawk when hunting for new Blue Magic spells, waiting for the monster to use that one ability? Are you sick and tired of going AFK until the monster dies, losing out on precious time that could be better spent in other areas of FFXI?

If so then your savior is here! BLUAlert!

This add-on will monitor monster abilities for Blue Magic spells that you don't know. When one is detected it will write a message into chat and play a sound to notify you.

Now you can relax while you AFK with the knowledge that you'll be able to come back and kill the monster right after it uses that one ability!