AutoRA v. 2.0.0

AutoRA simply causes ranged attacks to behave like the melee Auto-Attack while your weapon is drawn.  If no weapon is drawn or you put your weapon away, your ranged attacks will cease.

||||||||||||||||||||||DISCLAIMER||||||||||||||||||||||||
AutoRA will not consider any ammo you have equipped!
Be warned.  If you have your equipment window open, spellcast WILL NOT change your ammo!!!
I am not responsible for any lost ammo due to AutoRA.

||||||||||||||||||||||IMPORTANT!!|||||||||||||||||||||||
AutoRA will change any keybinds for the following keys:
Ctrl + D:  Start Ranged attacking.  (If no weapon drawn, fires a single ranged attack)
Alt + D:  Force stop Ranged attacking.  (Automatically done when weapon is put away.)


Commands:

ara [options]
	start		- Starts Ranged Attacking (Identical to CTRL + D)
	stop		- Stops Ranged Attacking (Identical to ALT + D)
	shoot		- Fires a ranged attack
	haltontp	- Toggles automatic halt upon reaching 1000 TP
	help   		- Shows Version info and available commands
