# giltracker
This addon displays the current gil, similar to the FFXIV Gil HUD widget.

![Imgur](https://i.imgur.com/vZ8NkDr.png)

## How to edit the settings
1. Login to your character in FFXI
2. Edit the addon settings file: **_Windower4\addons\giltracker\data\settings.xml_**
3. Save the file
4. Press Insert in FFXI to access the windower console
5. Type ``` lua r giltracker ``` to reload the addon
6. Press Insert in FFXI again to close the windower console
