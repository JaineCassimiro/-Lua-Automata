Author: Balloon(Cerberus)

Roll Tracker, for COR

This addon instantly displays your roll number, it's effect, and whether the roll is lucky or not. (As opposed to the 5 second delay you find with the chatlog. 

If you have rolled a lucky roll, it will also prompt you and automatically stop you from doubling up on it (which can be bypassed by either doubling up again, or typing //rolltracker autostop. This currently doesn't work if you are also using Gearswap.

To have the Lucky and Unlucky numbers of a roll displayed once per roll type //rolltracker luckyinfo

Enjoy.
