# enemybar

This is an addon for Windower4 for FFXI. It creates a big health bar for the target to make it easy to see.
