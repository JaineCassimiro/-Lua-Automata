#SpellCheck

This addon lists spells you haven't unlocked yet.

##Usage

//spellcheck whm | blm | smn | nin | brd | blu | geo | tru

##Credits
shinpad, trv, Arcon et al. at 
http://forums.windower.net/index.php?/topic/938-blu-spell-checklist-script/
and
http://forums.windower.net/index.php?/topic/973-trust-checklist-script/

##Release Notes

###1.0.2 - 2015-12-15
* Added Sleepga I/II spell exception as the spells were listed in spells.lua twice.

###1.0.1 - 2015-11-21
* Added spell exceptions.

###1.0.0 - 2015-11-15
* Initial release.
