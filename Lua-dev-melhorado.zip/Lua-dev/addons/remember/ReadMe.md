# Remember

This addon is designed to detect allies that have been forgotten by the server and send information request packets that will cause them to spawn.