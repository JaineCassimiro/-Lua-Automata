Authors: Krizz

Version: 1

Date: 20130419

Dynamis Helper

Abbreviation: //dh

Commands:
* help - Shows a menu of commands in game
* timer [on/off] - Displays a timer each time a mob is staggered.
* tracker [on/off/reset/pos x y] - Tracks the amount of currency obtained.
* proc [on/off/pos x y] - Displays the proc for the targeted mob.
* ll create - Creates and loads a light luggage profile that will automatically lot currency.
