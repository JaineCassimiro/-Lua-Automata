Author: Chiaia
Version: 1.0
Automatically hits the enter key twice as you first load up the game so you don't timeout on the warning message if you happen to like to tab out as it launches.
It take about 5 to 10 seconds to start to do this. If you happen to manually do it faster if will just unload itself since it serves no other purpose.

Abbreviation: //ake, //autoinvite

Commands:
* There are currently no commands.
