Author: Byrth

Version: 1.2

Respond

Abbreviation: N/A

Commands: N/A

Purpose: Simply plugin that allows text responses. Specifically, it aliases "input /tell <name>" to 'r' so you can use //r to respond to the last person who sent you a tell.