**Author:** Ricky Gall  
**Version:** 2.02 
**Description:**  
Watches buffs/debuffs and sends messages to alts when you gain certain
ones. Also, automatically uses echo drops if you get silenced.

**Abbreviation:** //aecho

**Commands:**
 1. aecho watch &lt;buffname&gt; --adds buffname to the tracker
 2. aecho unwatch &lt;buffname&gt; --removes buffname from the tracker
 3. aecho trackalt --Toggles alt buff/debuff messages on main (this requires send addon)
 4. aecho sitrack --When sneak/invis begin wearing passes this message to your alts
 5. aecho list --lists buffs being tracked
 6. aecho toggle --Toggles off automatic echo drop usage (in case you need this off. does not remain off across loads.)
       