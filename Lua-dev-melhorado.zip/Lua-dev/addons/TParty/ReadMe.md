# TParty

Shows a target's HP percentage next to their health bar and displays party and alliance member's TP. Unlike SE's version of TP display this also works on Trusts. Both options can be disabled in the settings.
