# Stubborn
A Windower 4 addon to prevent unnecessary "Call for help!"

Stubborn is a light weight replacement to the old CFHProtect addon. 

If you need to call for help. Type //stubborn or //cfh.
