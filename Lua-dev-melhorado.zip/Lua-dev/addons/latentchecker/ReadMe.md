LatentChecker
=============

Description: Checks weapon skill points of valid weapons.

Instructions: Use "//latentchecker run" or "//lc run" to check the weapon skill points of all valid weapons in your inventory.

Warning: Using it will unequip your main/sub/ranged weapons, and it takes about 5 seconds to check each weapon in your inventory.