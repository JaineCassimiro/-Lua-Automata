Use the line "silence mode 0" to not allow any lines to go through.  
Use the line "silence mode 1" to allow 1 line through indicting that your gear has been changed.

