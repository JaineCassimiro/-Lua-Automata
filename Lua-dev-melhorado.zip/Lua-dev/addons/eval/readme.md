Author: Aureus
Version: 1.0
Addon to evaluate lua code via windower commands

Abbreviation: //eval

Use //eval to run arbitrary lua code.  For example, try:  
//eval print(windower.ffxi.get_player().name)
