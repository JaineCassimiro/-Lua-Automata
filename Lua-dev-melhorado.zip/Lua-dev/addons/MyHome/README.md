# MyHome
## English
- Automatically choose and uses a warp spell or an item.

### Command
- `//mh` OR `//warp`
- `//mh all` OR `//warp all` will warp all characters.


- Priorities are:
    1. Warp <me> - require learned and main job or sub job BLM.
    2. Warp II <me>
    3. Warp Ring - search inventory and wardrobes.
    4. Warp Cudgel
    5. Instant Warp - search inventory.

## 日本語
- デジョンやデジョン系アイテムをリキャストに応じて自動で選択、使用します。

### Command
- `//mh` または `//warp`
- `//mh all` または `//warp all` すべての文字をワープします。
- 優先順位:


    1. デジョン <me> - 習得済かつメインまたはサポートジョブが黒魔道士
    2. デジョンII <me>
    3. デジョンリング - マイバッグ、またはワードローブ(1~4)を検索
    4. デジョンカジェル
    5. 呪符デジョン - マイバッグを検索
