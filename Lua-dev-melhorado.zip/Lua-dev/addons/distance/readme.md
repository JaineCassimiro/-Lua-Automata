# Distance

Emulates the functionality of the Distance plugin. Shows the distance towards the current target in yalms. Useful for range estimations.