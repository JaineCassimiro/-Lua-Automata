Commands:

zonetimer posX # 
    change the x position
  
zonetimer posY #
    change the y position
    
zonetimer fontsize #
    change the fontsize
    
zoentimer help
    print these instructions in the log
    
Original plugin by Krellion. 
