# TreasurePool

Replacement for the Treasure Pool thats shows time till the item auto drop and who is the current winning lot.
