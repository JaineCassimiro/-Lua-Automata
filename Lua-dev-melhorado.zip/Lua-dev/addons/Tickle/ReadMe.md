# Tickle

Displays the time remaining until your next resting tick.
