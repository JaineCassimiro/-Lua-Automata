# ConsoleBG

Creates a background shadow for the console window to make it more readable.
