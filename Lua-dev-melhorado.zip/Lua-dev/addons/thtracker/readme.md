Authors: Krizz

Version: 1.0

Date: 20170509

TH Tracker

Abbreviation: //th

Commands:
* help - Shows a menu of commands in game
* pos x y - Positions the TH box. Default location is 100,400.
* hide - Hides the box
* show - Shows the box





