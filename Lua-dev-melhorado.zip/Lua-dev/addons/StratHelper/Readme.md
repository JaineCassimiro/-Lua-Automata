StratHelper
=====

StratHelper is a simple helper addon for Spellcast for Scholar Stratagems. It will automatically calculate the number of stratagems you have and push them into spellcast variables to allow you to use them in your xmls. This should be accurate to within a second or so.

If at any time your strat value is incorrect, then wait until all your stratagems have reset then type `//resetstrats`. This will reset everything back to neutral again.

The variables to use in spellcast are:
`_SCH_Strats_Current` for the current number of strats available
`_SCH_Strats_Max` for the maximum number of strats available to you

