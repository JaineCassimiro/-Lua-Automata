Job Change AddOn.

Allows command line job change as long as you're within 6 yalms of a Job Change NPC. 

Usage:
* //jc main job - change just main job
* //jc sub job - change just sub job
* //jc main/sub - change both jobs at the same time.
* //jc reset   (Resets JA's by changing your sub job off and back)


If you are already the slot and job you want (IE you're already WAR and want to change MAIN to war) we'll temp-change to another job and change back to WAR.

If your sub or main conflicts with the target job change (IE: You're main WAR and want to change to sub WAR) we'll temp-change MAIN to another job (random starter), then change sub to WAR.

