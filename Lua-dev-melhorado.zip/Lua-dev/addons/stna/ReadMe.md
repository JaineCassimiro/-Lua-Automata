**Author:** Ricky Gall  
**Version:** 1.07  
**Description:**  
Addon to enable 1 macro status removal with the help of send.

**Abbreviation:** //stna

**Commands:**
 1. //stna

**Removal Priority:**
 1. Doom
 2. Curse
 3. Petrification
 4. Paralysis
 5. Plague
 6. Silence
 7. Blindness
 8. Poison
 9. Diseased
