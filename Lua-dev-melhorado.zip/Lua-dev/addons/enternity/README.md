**Author:** Giuliano Riccio  
**Version:** v 1.20131102

# Enternity #

Enters "Enter" automatically when prompted during a cutscene or when talking to NPCs. It will not skip choice dialog boxes.

----

##Changelog##
### v1.20130620 ###
* **fix:** Sentences that contain items will not be skipped.
* **fix:** Added NPCs exceptions.

### v1.20130607 ###
* **change:** Changed from artificial button press to ignoring the stop. Allows to type text freely while it goes through cutscenes.

### v1.20130606 ###
* First release.
