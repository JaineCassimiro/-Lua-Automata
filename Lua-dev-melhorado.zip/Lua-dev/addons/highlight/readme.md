
##Description
This addon highlights the names of the people in your party, and highlights their name when it appears in chat. 

The colors you select in this file will override any colours specified by other addons, for instance, Rolltracker and Battlemod

##Features
The colors of this addon are based on the default Battlemod colors, and they will be pulled in from your battlemod file. If you do not use battlemod, it will pull the colors from settings file in the data folder.

It also changes any common mispellings of peoples names, or nicknames uses into their correct name, and colours them accordingly. This feature will eventually plugin to the chatmon functionality.

##Previous Mentions

Highlight also tracks when people mentions you. You can view these back at any time by typing //highlight view <optional number of views>. 
If you want to add these mentions to a text file you can do this by typing //highlight write.